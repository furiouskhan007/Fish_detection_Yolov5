# Fish Species Classification > 2023-05-29 7:55am
https://universe.roboflow.com/research-vpani/fish-species-classification

Provided by a Roboflow user
License: CC BY 4.0

